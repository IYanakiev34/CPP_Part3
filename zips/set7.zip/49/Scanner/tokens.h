#ifndef INCLUDED_TOKENS_
#define INCLUDED_TOKENS_

struct Tokens
{
    // Symbolic tokens:
    enum Tokens_
    {
        WRITE = 257,
        IDENT,
        NUMBER,
    };

};

#endif
