#include "main.ih"

int main()
{
  Parser parser;
  parser.parse();
}