#include "Counter.ih"

std::size_t Counter::s_actualCount = 0;
std::size_t Counter::s_globalCount = 0;