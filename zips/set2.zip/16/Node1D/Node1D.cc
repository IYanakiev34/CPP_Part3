#include "Node1D.ih"

Node1D::Node1D(OwnerNode * owner)
  :
  d_owner(owner)
{}