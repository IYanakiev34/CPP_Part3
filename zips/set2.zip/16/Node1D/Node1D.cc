#include "Node1D.ih"

Node1D::Node1D(Node1D * owner)
  :
  d_owner(owner)
{

}