#ifndef SET2_OWNERNODE_H
#define SET2_OWNERNODE_H

                            // A class that can be inherited to be "tagged" as a
                            // "node" that hold other nodes.
class OwnerNode
{};

#endif //SET2_OWNERNODE_H
