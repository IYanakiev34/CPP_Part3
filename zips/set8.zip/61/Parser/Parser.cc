#include "Parser.ih"
Parser::Parser(char sep)
  : d_scanner(sep)
{}
