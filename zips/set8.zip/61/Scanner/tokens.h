#ifndef INCLUDED_TOKENS_
#define INCLUDED_TOKENS_

struct Tokens
{
    // Symbolic tokens:
    enum Tokens_
    {
        NAME = 257,
        TRUE,
        FALSE,
        NUMBER,
        SEPERATOR,
    };

};

#endif
