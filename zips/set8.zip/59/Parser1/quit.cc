#include "Parser.ih"
void Parser::quit()
{
  ACCEPT();
}
