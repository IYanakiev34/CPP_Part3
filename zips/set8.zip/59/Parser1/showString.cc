#include "Parser.ih"
void Parser::showString(string const &value)
{
  cout << value;
}
