#include "Parser.ih"
void Parser::showInt(int value)
{
  cout << value;
}
