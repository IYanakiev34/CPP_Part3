#include "Parser.ih"
void Parser::showDouble(double value)
{
  cout << value;
}
