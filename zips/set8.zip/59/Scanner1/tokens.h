#ifndef INCLUDED_TOKENS_
#define INCLUDED_TOKENS_

struct Tokens
{
    // Symbolic tokens:
    enum Tokens_
    {
        INT = 257,
        STRING,
        DOUBLE,
        QUIT,
    };

};

#endif
