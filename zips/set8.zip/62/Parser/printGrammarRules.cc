#include "Parser.ih"
void Parser::printGrammarRules()
{
  cout << d_rules.print();
}
