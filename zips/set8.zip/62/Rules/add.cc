#include "Rules.ih"
void Rules::add(Rule const &rule)
{
  d_rules.push_back(rule);
}
