#include "OptInsert.ih"

OptInsert::OptInsert()
:
  d_insert(false),
  d_out(0)
{}
