#include "main.ih"

int main()
{
                              // Check addresses of instantiated template funcs
                              // in source1, source2.
  sourceFun1();
  sourceFun2();
}