#ifndef SET1_TEMPLATE_H
#define SET1_TEMPLATE_H

                            // Template function for demo. purposes
template <typename Type>
Type templateFun(Type param1)
{
  return param1;
}

#endif //SET1_TEMPLATE_H
